package com.yasirkula.unity;

public interface FileBrowserDirectoryReceiver
{
	void OnDirectoryPicked( String rawUri, String name );
}
